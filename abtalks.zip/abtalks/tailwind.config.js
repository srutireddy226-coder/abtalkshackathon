/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      colors: {
        void: {
          DEFAULT: '#0A0E16',
          50: '#161C2A',
          100: '#131826',
          200: '#0F1420',
          300: '#0A0E16',
        },
        ink: {
          100: '#F4F6FB',
          300: '#C4CAD9',
          400: '#8A93A6',
          600: '#5B6479',
        },
        ember: {
          300: '#FFB088',
          400: '#FF9257',
          500: '#FF7A3D',
          600: '#E85D2C',
          700: '#C7441C',
        },
        teal: {
          300: '#8FF5E1',
          400: '#37E6C4',
          500: '#16C9A8',
          600: '#0EA089',
        },
      },
      backgroundImage: {
        'ember-gradient': 'linear-gradient(135deg, #FF9257 0%, #FF7A3D 45%, #E85D2C 100%)',
        'teal-gradient': 'linear-gradient(135deg, #8FF5E1 0%, #37E6C4 50%, #16C9A8 100%)',
        'aurora': 'radial-gradient(circle at 20% 20%, rgba(255,122,61,0.16), transparent 40%), radial-gradient(circle at 80% 0%, rgba(55,230,196,0.12), transparent 45%), radial-gradient(circle at 50% 100%, rgba(255,122,61,0.08), transparent 50%)',
      },
      boxShadow: {
        card: '0 1px 0 rgba(255,255,255,0.04) inset, 0 20px 40px -20px rgba(0,0,0,0.6)',
        ember: '0 0 0 1px rgba(255,122,61,0.35), 0 8px 30px -8px rgba(255,122,61,0.45)',
        glow: '0 0 40px -8px rgba(255,122,61,0.5)',
      },
      keyframes: {
        flicker: {
          '0%, 100%': { opacity: 1, transform: 'scale(1)' },
          '50%': { opacity: 0.85, transform: 'scale(0.97)' },
        },
        rise: {
          '0%': { opacity: 0, transform: 'translateY(10px)' },
          '100%': { opacity: 1, transform: 'translateY(0)' },
        },
        pop: {
          '0%': { transform: 'scale(0.8)', opacity: 0 },
          '60%': { transform: 'scale(1.06)', opacity: 1 },
          '100%': { transform: 'scale(1)' },
        },
      },
      animation: {
        flicker: 'flicker 2.4s ease-in-out infinite',
        rise: 'rise 0.5s cubic-bezier(0.16,1,0.3,1) both',
        pop: 'pop 0.5s cubic-bezier(0.16,1,0.3,1) both',
      },
    },
  },
  plugins: [],
}

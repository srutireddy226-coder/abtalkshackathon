# ABTalks — 60-Day Student Command Center

A redesigned student experience for the ABTalks 60-day coding challenge. Built in a 48-hour hackathon.

## The Problem

Most coding-challenge trackers are just checklists. The moment a student misses a day, the app either punishes them (a red X, a broken streak) or ignores it entirely. Both responses cause students to quietly drop out — the single biggest failure mode of 60-day challenges.

## The Solution

The Command Center reframes the 60 days as a personal journey, not a to-do list: a live progress ring, a streak that's worth protecting, badges for real milestones, and — the core differentiator — **Recovery Mode**, which turns a missed day into a personalized comeback plan instead of a dead end.

## Key Features

- **Challenge Progress** — an animated flame-ring hero stat showing day count and % complete
- **Daily Mission** — today's challenge front and center, with difficulty, time estimate, and skills
- **Streak Tracking** — live streak counter with a 7-day activity strip
- **Recovery Mode** *(unique feature)* — detects a missed day and generates a two-step catch-up plan (recovery task + today's challenge) so the student's journey never just stops
- **Achievements** — six milestone badges with locked/unlocked states and unlock celebrations
- **Proof of Work** — submit a GitHub repo, LinkedIn post, live demo link, and a screenshot for any day
- **60-Day Calendar** — every day color-coded (completed / today / recovery / missed / upcoming), click into any day
- **Progress Analytics** — completion %, current & longest streak, missed days, projects shipped, and a journey chart
- **Contextual Motivation** — copy that adapts to where the student actually is (Day 1, mid-streak, post-miss, near the finish)
- **Light / Dark Theme Toggle**, fully responsive desktop → tablet → mobile

## Unique Feature: Recovery Mode

Recovery Mode is the product's core bet: a missed day isn't framed as failure, it's framed as a plan. The dashboard automatically surfaces:

> "Looks like you missed Day 12. Let's get you back on track. 💪"

...with a two-step recovery plan (a 30-minute quick recovery task, plus today's regular challenge) and a single "Start Recovery" action. When there's nothing to recover, the same card celebrates: "You're on track! Keep the streak alive 🔥". This logic is fully dynamic — it reacts to real state, not hardcoded copy.

## Tech Stack

- React 18 + Vite
- Tailwind CSS (custom design tokens — see `tailwind.config.js`)
- React Router (hash routing, so it works from a static file host with no server config)
- Recharts (weekly + journey progress charts)
- lucide-react (icons)
- `localStorage` for persistence — no backend, no auth, by design (see hackathon constraints)

## How It Works

All 60 days of mock challenge data live in `src/data/challenges.js`, generated from five themed curriculum "arcs" (Foundations → JavaScript → React → Applied Projects → Capstone). Student progress (`currentDay`, per-day status, submitted proofs) is owned by a single `useStudentProgress` hook, shared app-wide through React Context, and persisted to `localStorage` under the key `abtalks:state:v1`. Streaks, completion %, and achievement unlocks are all computed live from that state — nothing is hardcoded.

The demo seed state starts the app at **Day 18**, with an 11-day opening streak, an unresolved miss on Day 12 (so Recovery Mode is visible immediately), and a fresh 5-day rebuild streak heading into today — a realistic, honest state rather than a cosmetic number.

## Project Structure

```
src/
  components/   Reusable UI: ProgressCard, ChallengeCard, StreakCard,
                RecoveryCard, AchievementCard, ChallengeCalendar,
                ProofSubmission, ProgressChart, Navbar, Sidebar, BottomNav...
  pages/        Landing, Dashboard, Challenges, ChallengeDetail,
                ProgressPage, Achievements, Settings
  data/         challenges.js (60-day mock curriculum), studentState.js
                (seed state, achievement rules, motivational copy)
  hooks/        useLocalStorage, useStudentProgress
  context/      StudentContext (shares one progress instance app-wide)
  utils/        progress.js (streaks, stats, recovery plan, motivation)
```

## Run Locally

```bash
npm install
npm run dev       # start the dev server
npm run build     # production build → dist/
npm run preview   # preview the production build
```

Requires Node 18+.

## Deployment

This is a static Vite build with no backend — it deploys anywhere that serves static files: Vercel, Netlify, GitHub Pages, or Cloudflare Pages. Routing uses `HashRouter`, so no server-side rewrite rules are needed.

```bash
npm run build
# deploy the dist/ folder
```

## Future Improvements

- Real authentication + a backend so progress is portable across devices
- Peer leaderboard and cohort-wide streak challenges
- GitHub API integration to auto-verify proof-of-work submissions
- Push notifications for streak-at-risk reminders
- Mentor/reviewer flow for proof-of-work feedback

## Screenshots

_Add screenshots of the Landing page, Dashboard, Recovery Mode card, Challenge Calendar, and Achievements page here before submitting._

import React from 'react'
import { Link } from 'react-router-dom'
import { Flame, ArrowRight, CalendarDays, Trophy, LifeBuoy, LineChart, GitBranch, Github, Users, Code2 } from 'lucide-react'
import FlameRing from '../components/FlameRing'

const STATS = [
  { value: '60', label: 'Days', icon: CalendarDays },
  { value: '60', label: 'Daily Challenges', icon: Code2 },
  { value: '2,400+', label: 'Projects Built', icon: GitBranch },
  { value: '87%', label: 'Avg. Student Progress', icon: LineChart },
]

const FEATURES = [
  { icon: Flame, title: 'Streak Tracking', desc: 'A living streak counter that makes every day of consistency visible and worth protecting.' },
  { icon: LifeBuoy, title: 'Recovery Mode', desc: "Miss a day? Get a personalized catch-up plan instead of a guilt trip. Your journey keeps moving." },
  { icon: Trophy, title: 'Achievements', desc: 'Unlock badges as you hit real milestones — from your first project to the 60-day finish line.' },
  { icon: CalendarDays, title: 'Challenge Calendar', desc: "See your entire 60-day arc at a glance, and jump into any day's challenge in one tap." },
]

export default function Landing() {
  return (
    <div className="min-h-screen bg-void text-ink-100">
      <header className="max-w-[1400px] mx-auto px-6 lg:px-10 h-20 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-ember-gradient flex items-center justify-center shadow-ember">
            <Flame size={17} className="text-void-300" strokeWidth={2.5} />
          </div>
          <span className="font-display font-semibold text-lg tracking-tight">ABTalks</span>
        </div>
        <Link to="/app" className="btn-secondary text-sm">
          Open Dashboard <ArrowRight size={15} />
        </Link>
      </header>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-aurora pointer-events-none" />
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 pt-16 pb-20 lg:pt-24 lg:pb-28 relative">
          <div className="grid lg:grid-cols-[1.1fr_0.9fr] gap-14 items-center">
            <div className="animate-rise">
              <p className="eyebrow mb-5 text-ember-400">The ABTalks 60-Day Coding Challenge</p>
              <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.05] tracking-tight mb-6">
                60 Days.
                <br />
                One Challenge.
                <br />
                <span className="bg-ember-gradient bg-clip-text text-transparent">One Transformation.</span>
              </h1>
              <p className="text-ink-400 text-base sm:text-lg max-w-lg mb-8 leading-relaxed">
                Turn consistent coding into a habit, build real projects, and prove your progress every day.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link to="/app" className="btn-primary">
                  Start Your Journey <ArrowRight size={16} />
                </Link>
                <Link to="/app/challenges" className="btn-secondary">
                  View Challenge
                </Link>
              </div>
            </div>

            <div className="flex justify-center lg:justify-end animate-rise" style={{ animationDelay: '120ms' }}>
              <div className="glass-card p-8 w-full max-w-sm">
                <div className="flex justify-center mb-6">
                  <FlameRing percent={30} size={168} label="30%" sublabel="Day 18 / 60" />
                </div>
                <div className="grid grid-cols-2 gap-3 text-center">
                  <div className="rounded-xl bg-white/[0.03] border border-white/[0.06] py-3">
                    <p className="font-display font-bold text-xl text-ember-400">5</p>
                    <p className="text-[11px] text-ink-400 mt-0.5">Day streak</p>
                  </div>
                  <div className="rounded-xl bg-white/[0.03] border border-white/[0.06] py-3">
                    <p className="font-display font-bold text-xl text-teal-400">17</p>
                    <p className="text-[11px] text-ink-400 mt-0.5">Completed</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 pb-20">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {STATS.map(({ value, label, icon: Icon }) => (
            <div key={label} className="glass-card p-5 sm:p-6">
              <Icon size={18} className="text-ember-400 mb-3" />
              <p className="font-display text-2xl sm:text-3xl font-bold">{value}</p>
              <p className="text-ink-400 text-sm mt-1">{label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-[1400px] mx-auto px-6 lg:px-10 pb-24">
        <div className="max-w-xl mb-10">
          <p className="eyebrow mb-3">Why It's Different</p>
          <h2 className="font-display text-2xl sm:text-3xl font-semibold">
            Built for the days you show up — and the days you almost don't.
          </h2>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          {FEATURES.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="glass-card p-6 hover:border-ember-500/20 transition-colors">
              <div className="w-10 h-10 rounded-xl bg-ember-gradient flex items-center justify-center mb-4 shadow-ember">
                <Icon size={18} className="text-void-300" />
              </div>
              <h3 className="font-display font-semibold mb-1.5">{title}</h3>
              <p className="text-ink-400 text-sm leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-white/[0.06] py-8">
        <div className="max-w-[1400px] mx-auto px-6 lg:px-10 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-ink-400">
          <span className="inline-flex items-center gap-2">
            <Flame size={14} className="text-ember-400" /> ABTalks 60-Day Student Command Center
          </span>
          <span className="inline-flex items-center gap-4">
            <span className="inline-flex items-center gap-1.5">
              <Users size={14} /> Built for the ABTalks community
            </span>
            <a href="#" className="inline-flex items-center gap-1.5 hover:text-ink-100">
              <Github size={14} /> Source
            </a>
          </span>
        </div>
      </footer>
    </div>
  )
}

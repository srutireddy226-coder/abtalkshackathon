import React, { useState, useMemo } from 'react'
import { useStudent } from '../context/StudentContext'
import { CHALLENGES } from '../data/challenges'
import { calendarStatusFor } from '../utils/progress'
import ChallengeCalendar from '../components/ChallengeCalendar'
import ChallengeCard from '../components/ChallengeCard'

const FILTERS = ['All', 'Completed', 'Today', 'Missed', 'Upcoming']

export default function Challenges() {
  const { state, stats } = useStudent()
  const [filter, setFilter] = useState('All')

  const filtered = useMemo(() => {
    return CHALLENGES.filter((c) => {
      const status = calendarStatusFor(state.dayStatus, c.day, stats.currentDay)
      if (filter === 'All') return true
      if (filter === 'Completed') return status === 'completed' || status === 'recovery'
      return status.toLowerCase() === filter.toLowerCase()
    })
  }, [filter, state.dayStatus, stats.currentDay])

  return (
    <div className="space-y-6 animate-rise">
      <div>
        <h1 className="font-display text-xl sm:text-2xl font-semibold">Challenges</h1>
        <p className="text-ink-400 text-sm mt-0.5">All 60 days of the ABTalks challenge, in one place.</p>
      </div>

      <ChallengeCalendar dayStatus={state.dayStatus} currentDay={stats.currentDay} />

      <div className="glass-card p-6">
        <div className="flex items-center gap-2 mb-5 overflow-x-auto no-scrollbar">
          {FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`shrink-0 px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                filter === f ? 'bg-ember-gradient text-void-300 shadow-ember' : 'bg-white/[0.03] text-ink-400 hover:text-ink-100 border border-white/[0.06]'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        <div className="space-y-2.5">
          {filtered.map((c) => (
            <ChallengeCard key={c.id} challenge={c} status={calendarStatusFor(state.dayStatus, c.day, stats.currentDay)} variant="compact" />
          ))}
          {filtered.length === 0 && <p className="text-center text-ink-400 text-sm py-10">No challenges match this filter.</p>}
        </div>
      </div>
    </div>
  )
}

import React from 'react'
import { Flame, CheckCircle2, XCircle, Layers, TrendingUp, Award } from 'lucide-react'
import { useStudent } from '../context/StudentContext'
import { JourneyChart, WeeklyProgressChart } from '../components/ProgressChart'
import ChallengeCalendar from '../components/ChallengeCalendar'

export default function ProgressPage() {
  const { stats, state } = useStudent()

  const metrics = [
    { icon: TrendingUp, label: 'Overall completion', value: `${stats.completionPct}%`, accent: 'ember' },
    { icon: Flame, label: 'Current streak', value: `${stats.currentStreak} days`, accent: 'ember' },
    { icon: Award, label: 'Longest streak', value: `${stats.longestStreak} days`, accent: 'teal' },
    { icon: CheckCircle2, label: 'Challenges completed', value: stats.completedCount, accent: 'teal' },
    { icon: XCircle, label: 'Challenges missed', value: stats.missedCount, accent: 'ember' },
    { icon: Layers, label: 'Projects completed', value: stats.projectsCompleted, accent: 'teal' },
  ]

  return (
    <div className="space-y-6 animate-rise">
      <div>
        <h1 className="font-display text-xl sm:text-2xl font-semibold">My Progress</h1>
        <p className="text-ink-400 text-sm mt-0.5">A full breakdown of how your 60 days are going.</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {metrics.map(({ icon: Icon, label, value, accent }) => (
          <div key={label} className="glass-card p-5">
            <Icon size={17} className={accent === 'ember' ? 'text-ember-400 mb-3' : 'text-teal-400 mb-3'} />
            <p className="font-display text-2xl font-bold">{value}</p>
            <p className="text-ink-400 text-xs mt-1">{label}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <JourneyChart stats={stats} />
        <WeeklyProgressChart dayStatus={state.dayStatus} currentDay={stats.currentDay} />
      </div>

      <ChallengeCalendar dayStatus={state.dayStatus} currentDay={stats.currentDay} />
    </div>
  )
}

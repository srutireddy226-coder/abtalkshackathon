import React, { useState } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { ArrowLeft, Clock, Zap, ExternalLink, CheckSquare, Square, CheckCircle2 } from 'lucide-react'
import { getChallengeByDay } from '../data/challenges'
import { calendarStatusFor } from '../utils/progress'
import { useStudent } from '../context/StudentContext'
import ProofSubmission from '../components/ProofSubmission'

const DIFFICULTY_STYLES = {
  Easy: 'text-teal-400 bg-teal-400/10 border-teal-400/20',
  Medium: 'text-ember-400 bg-ember-400/10 border-ember-400/20',
  Hard: 'text-ember-600 bg-ember-600/10 border-ember-600/25',
}

export default function ChallengeDetail() {
  const { day } = useParams()
  const navigate = useNavigate()
  const dayNum = Number(day)
  const challenge = getChallengeByDay(dayNum)
  const { state, stats, markComplete, submitProof, startRecovery } = useStudent()
  const [checked, setChecked] = useState({})

  if (!challenge) {
    return (
      <div className="glass-card p-8 text-center">
        <p className="text-ink-400">That challenge doesn't exist.</p>
        <Link to="/app/challenges" className="btn-secondary inline-flex mt-4">Back to Challenges</Link>
      </div>
    )
  }

  const status = calendarStatusFor(state.dayStatus, dayNum, stats.currentDay)
  const isDone = status === 'completed' || status === 'recovery'
  const isMissed = status === 'missed'
  const existingProof = state.proofs[dayNum]

  const toggleReq = (idx) => setChecked((prev) => ({ ...prev, [idx]: !prev[idx] }))

  const handleMarkComplete = () => {
    if (isMissed) startRecovery(dayNum)
    else markComplete(dayNum)
  }

  return (
    <div className="space-y-6 animate-rise max-w-4xl">
      <button onClick={() => navigate(-1)} className="btn-ghost text-sm">
        <ArrowLeft size={15} /> Back
      </button>

      <div className="glass-card p-6 sm:p-8">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <span className="font-mono text-xs text-ink-400 tracking-wider">DAY {challenge.day} / 60 · {challenge.arc}</span>
          <span className={`text-[11px] font-medium px-2.5 py-1 rounded-md border ${DIFFICULTY_STYLES[challenge.difficulty]}`}>{challenge.difficulty}</span>
        </div>

        <h1 className="font-display text-2xl sm:text-3xl font-semibold mb-3">{challenge.title}</h1>
        <p className="text-ink-400 leading-relaxed mb-5">{challenge.description}</p>

        <div className="flex flex-wrap items-center gap-4 mb-6 text-sm text-ink-300">
          <span className="inline-flex items-center gap-1.5"><Clock size={15} className="text-ink-400" /> {challenge.estimatedTime}</span>
          <span className="inline-flex items-center gap-1.5"><Zap size={15} className="text-ink-400" /> {challenge.skills.join(' · ')}</span>
          {isDone && (
            <span className="inline-flex items-center gap-1.5 text-teal-400">
              <CheckCircle2 size={15} /> {status === 'recovery' ? 'Recovered' : 'Completed'}
            </span>
          )}
          {isMissed && <span className="text-ember-600 font-medium">Missed — recovery available</span>}
        </div>

        <div className="flex flex-wrap gap-3">
          {!isDone && (
            <button onClick={handleMarkComplete} className="btn-primary">
              {isMissed ? 'Start Recovery' : 'Mark Complete'}
            </button>
          )}
          <a href="#proof" className="btn-secondary">Submit Proof</a>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-6">
        <div className="glass-card p-6">
          <p className="eyebrow mb-3">Learning Objectives</p>
          <ul className="space-y-2.5">
            {challenge.learningObjectives.map((obj, i) => (
              <li key={i} className="text-sm text-ink-300 flex gap-2.5">
                <span className="text-ember-400 mt-0.5">→</span>
                {obj}
              </li>
            ))}
          </ul>
        </div>

        <div className="glass-card p-6">
          <p className="eyebrow mb-3">Resources</p>
          <ul className="space-y-2">
            {challenge.resources.map((r, i) => (
              <li key={i}>
                <a href={r.url} target="_blank" rel="noreferrer" className="text-sm text-ink-300 hover:text-ember-400 inline-flex items-center gap-1.5 transition-colors">
                  <ExternalLink size={13} /> {r.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="glass-card p-6">
        <p className="eyebrow mb-4">Acceptance Checklist</p>
        <div className="space-y-2.5">
          {challenge.requirements.map((req, i) => (
            <button key={i} onClick={() => toggleReq(i)} className="w-full flex items-start gap-3 text-left group">
              {checked[i] ? (
                <CheckSquare size={18} className="text-teal-400 shrink-0 mt-0.5" />
              ) : (
                <Square size={18} className="text-ink-400 shrink-0 mt-0.5 group-hover:text-ink-100" />
              )}
              <span className={`text-sm ${checked[i] ? 'text-ink-400 line-through' : 'text-ink-300'}`}>{req}</span>
            </button>
          ))}
        </div>
      </div>

      <div id="proof">
        <ProofSubmission day={challenge.day} existingProof={existingProof} onSubmit={(proof) => submitProof(challenge.day, proof)} />
      </div>
    </div>
  )
}

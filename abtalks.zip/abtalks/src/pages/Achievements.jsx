import React from 'react'
import { useStudent } from '../context/StudentContext'
import AchievementCard from '../components/AchievementCard'

export default function Achievements() {
  const { achievements, stats } = useStudent()
  const unlockedCount = achievements.filter((a) => a.unlocked).length
  const next = achievements.find((a) => !a.unlocked)

  return (
    <div className="space-y-6 animate-rise">
      <div>
        <h1 className="font-display text-xl sm:text-2xl font-semibold">Achievements</h1>
        <p className="text-ink-400 text-sm mt-0.5">{unlockedCount} of {achievements.length} badges unlocked.</p>
      </div>

      {next && (
        <div className="glass-card p-5 flex items-center justify-between gap-4 flex-wrap">
          <div>
            <p className="eyebrow mb-1">Next Up</p>
            <p className="font-display font-semibold">{next.label}</p>
            <p className="text-ink-400 text-sm mt-0.5">{next.description}</p>
          </div>
          <div className="w-full sm:w-40 h-2 rounded-full bg-white/[0.06] overflow-hidden">
            <div className="h-full bg-ember-gradient rounded-full transition-all duration-700" style={{ width: `${Math.min(100, (stats.completedCount / 30) * 100)}%` }} />
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
        {achievements.map((a) => (
          <AchievementCard key={a.id} achievement={a} />
        ))}
      </div>
    </div>
  )
}

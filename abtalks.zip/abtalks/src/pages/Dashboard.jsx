import React from 'react'
import { useStudent } from '../context/StudentContext'
import { getChallengeByDay } from '../data/challenges'
import ProgressCard from '../components/ProgressCard'
import ChallengeCard from '../components/ChallengeCard'
import StreakCard from '../components/StreakCard'
import RecoveryCard from '../components/RecoveryCard'
import MotivationBanner from '../components/MotivationBanner'
import { WeeklyProgressChart } from '../components/ProgressChart'

export default function Dashboard() {
  const { student, stats, state, recoveryPlan, motivation } = useStudent()
  const todayChallenge = getChallengeByDay(stats.currentDay)

  return (
    <div className="space-y-6 animate-rise">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="font-display text-xl sm:text-2xl font-semibold">Welcome back, {student.name.split(' ')[0]}</h1>
          <p className="text-ink-400 text-sm mt-0.5">Here's where your challenge stands today.</p>
        </div>
      </div>

      <MotivationBanner message={motivation} />

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <ProgressCard stats={stats} />
          {todayChallenge && <ChallengeCard challenge={todayChallenge} status="today" variant="hero" />}
          <WeeklyProgressChart dayStatus={state.dayStatus} currentDay={stats.currentDay} />
        </div>
        <div className="space-y-6">
          <RecoveryCard plan={recoveryPlan} />
          <StreakCard stats={stats} dayStatus={state.dayStatus} />
        </div>
      </div>
    </div>
  )
}

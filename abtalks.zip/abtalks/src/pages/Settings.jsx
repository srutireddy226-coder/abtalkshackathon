import React, { useState } from 'react'
import { RotateCcw, Bell, Moon, User } from 'lucide-react'
import { useStudent } from '../context/StudentContext'

export default function Settings() {
  const { student, resetDemo } = useStudent()
  const [notifs, setNotifs] = useState({ daily: true, streak: true, achievements: false })
  const [confirmReset, setConfirmReset] = useState(false)

  const handleReset = () => {
    if (!confirmReset) {
      setConfirmReset(true)
      window.setTimeout(() => setConfirmReset(false), 3000)
      return
    }
    resetDemo()
    setConfirmReset(false)
  }

  return (
    <div className="space-y-6 animate-rise max-w-2xl">
      <div>
        <h1 className="font-display text-xl sm:text-2xl font-semibold">Settings</h1>
        <p className="text-ink-400 text-sm mt-0.5">Manage your profile and challenge preferences.</p>
      </div>

      <div className="glass-card p-6">
        <p className="eyebrow mb-4 inline-flex items-center gap-2"><User size={13} /> Profile</p>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs text-ink-400 mb-1.5 block">Name</label>
            <div className="input">{student.name}</div>
          </div>
          <div>
            <label className="text-xs text-ink-400 mb-1.5 block">Handle</label>
            <div className="input">{student.handle}</div>
          </div>
        </div>
      </div>

      <div className="glass-card p-6">
        <p className="eyebrow mb-4 inline-flex items-center gap-2"><Bell size={13} /> Notifications</p>
        <div className="space-y-3">
          <Toggle label="Daily challenge reminder" checked={notifs.daily} onChange={() => setNotifs((n) => ({ ...n, daily: !n.daily }))} />
          <Toggle label="Streak at-risk alerts" checked={notifs.streak} onChange={() => setNotifs((n) => ({ ...n, streak: !n.streak }))} />
          <Toggle label="Achievement unlocks" checked={notifs.achievements} onChange={() => setNotifs((n) => ({ ...n, achievements: !n.achievements }))} />
        </div>
      </div>

      <div className="glass-card p-6">
        <p className="eyebrow mb-4 inline-flex items-center gap-2"><Moon size={13} /> Appearance</p>
        <p className="text-sm text-ink-400">Use the sun / moon icon in the top navigation bar to switch between dark and light mode anytime.</p>
      </div>

      <div className="glass-card p-6 border-ember-600/25">
        <p className="eyebrow mb-2 text-ember-500">Demo Data</p>
        <p className="text-sm text-ink-400 mb-4">Reset your progress back to the default Day 18 demo state — useful for re-running the hackathon demo.</p>
        <button onClick={handleReset} className="btn-secondary">
          <RotateCcw size={15} /> {confirmReset ? 'Click again to confirm' : 'Reset Demo Data'}
        </button>
      </div>

      <style>{`.input { width: 100%; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 0.75rem; padding: 0.6rem 0.85rem; font-size: 0.875rem; color: #F4F6FB; }`}</style>
    </div>
  )
}

function Toggle({ label, checked, onChange }) {
  return (
    <button onClick={onChange} className="w-full flex items-center justify-between py-1.5">
      <span className="text-sm text-ink-300">{label}</span>
      <span className={`w-10 h-6 rounded-full flex items-center px-0.5 transition-colors ${checked ? 'bg-ember-gradient justify-end' : 'bg-white/10 justify-start'}`}>
        <span className="w-5 h-5 rounded-full bg-white block shadow" />
      </span>
    </button>
  )
}

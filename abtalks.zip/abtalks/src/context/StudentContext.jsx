import React, { createContext, useContext } from 'react'
import { useStudentProgress } from '../hooks/useStudentProgress'

const StudentContext = createContext(null)

export function StudentProvider({ children }) {
  const value = useStudentProgress()
  return <StudentContext.Provider value={value}>{children}</StudentContext.Provider>
}

export function useStudent() {
  const ctx = useContext(StudentContext)
  if (!ctx) throw new Error('useStudent must be used within a StudentProvider')
  return ctx
}

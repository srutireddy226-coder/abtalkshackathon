import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { StudentProvider } from './context/StudentContext'
import AppLayout from './components/AppLayout'
import Landing from './pages/Landing'
import Dashboard from './pages/Dashboard'
import Challenges from './pages/Challenges'
import ChallengeDetail from './pages/ChallengeDetail'
import ProgressPage from './pages/ProgressPage'
import Achievements from './pages/Achievements'
import Settings from './pages/Settings'

export default function App() {
  return (
    <StudentProvider>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/app" element={<AppLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="challenges" element={<Challenges />} />
          <Route path="challenges/:day" element={<ChallengeDetail />} />
          <Route path="progress" element={<ProgressPage />} />
          <Route path="achievements" element={<Achievements />} />
          <Route path="settings" element={<Settings />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </StudentProvider>
  )
}

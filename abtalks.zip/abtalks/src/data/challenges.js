// Mock 60-day curriculum data. Deterministic — no randomness — so the demo
// state and the calendar always agree with each other.

const ARCS = [
  {
    range: [1, 10],
    name: 'Foundations',
    skills: ['HTML', 'CSS'],
    titles: [
      'Build a Semantic Portfolio Skeleton',
      'Style a Responsive Hero Section',
      'Create a CSS Grid Photo Wall',
      'Design a Pricing Table with Flexbox',
      'Build an Accessible Navigation Bar',
      'Animate a Card Hover State',
      'Recreate a Dribbble Login Screen',
      'Build a Mobile-First Blog Layout',
      'Style a Dark Mode Toggle',
      'Ship Your First Static Landing Page',
    ],
    difficulty: ['Easy', 'Easy', 'Easy', 'Medium', 'Easy', 'Medium', 'Medium', 'Medium', 'Easy', 'Hard'],
  },
  {
    range: [11, 25],
    name: 'JavaScript Core',
    skills: ['JavaScript'],
    titles: [
      'Build a Dynamic To-Do List',
      'Create a Countdown Timer',
      'Build a Quiz App with Score Tracking',
      'Fetch and Render API Data',
      'Build a Debounced Search Bar',
      'Create a Custom Modal Component',
      'Build a Local-Storage Notes App',
      'Implement Infinite Scroll',
      'Build a Drag-and-Drop Kanban Board',
      'Create a Form Validator from Scratch',
      'Build a Weather Dashboard',
      'Implement a Currency Converter',
      'Build a Recipe Finder App',
      'Create a Typing Speed Tester',
      'Build a Responsive Portfolio',
    ],
    difficulty: ['Medium', 'Easy', 'Medium', 'Medium', 'Medium', 'Medium', 'Medium', 'Hard', 'Hard', 'Medium', 'Hard', 'Medium', 'Hard', 'Medium', 'Hard'],
  },
  {
    range: [26, 40],
    name: 'React Fundamentals',
    skills: ['React', 'JavaScript'],
    titles: [
      'Set Up Your First React App',
      'Build a Component-Based Counter',
      'Master useState and Props',
      'Build a Controlled Form',
      'Fetch Data with useEffect',
      'Build a Reusable Card Component Library',
      'Implement Client-Side Routing',
      'Build a Shopping Cart with Context',
      'Create a Custom Hook for Local Storage',
      'Build a Movie Search App',
      'Implement Optimistic UI Updates',
      'Build a Multi-Step Form Wizard',
      'Create an Animated Tab System',
      'Build a Real-Time Chat UI (mock)',
      'Ship a Full Recipe Manager App',
    ],
    difficulty: ['Easy', 'Easy', 'Medium', 'Medium', 'Medium', 'Medium', 'Medium', 'Hard', 'Medium', 'Hard', 'Hard', 'Hard', 'Medium', 'Hard', 'Hard'],
  },
  {
    range: [41, 50],
    name: 'Applied Projects',
    skills: ['React', 'API Integration'],
    titles: [
      'Build a Budget Tracker with Charts',
      'Create a Habit Tracker Dashboard',
      'Build a Markdown Note Editor',
      'Implement Auth UI (mock)',
      'Build a Kanban Task Manager',
      'Create a Music Player Interface',
      'Build a GitHub Profile Explorer',
      'Implement a Dark/Light Theme System',
      'Build a Portfolio CMS (mock backend)',
      'Ship a Personal Finance Dashboard',
    ],
    difficulty: ['Hard', 'Hard', 'Medium', 'Hard', 'Hard', 'Medium', 'Medium', 'Medium', 'Hard', 'Hard'],
  },
  {
    range: [51, 60],
    name: 'Capstone Sprint',
    skills: ['React', 'Deployment'],
    titles: [
      'Architect Your Capstone Project',
      'Build the Capstone Core Feature',
      'Add Responsive Polish to Capstone',
      'Write Tests for Critical Flows',
      'Optimize Performance & Bundle Size',
      'Deploy Your Capstone Project',
      'Write a Case Study README',
      'Record a Demo Walkthrough',
      'Get Peer Feedback & Iterate',
      'Ship Day 60: Present Your Transformation',
    ],
    difficulty: ['Medium', 'Hard', 'Medium', 'Hard', 'Medium', 'Medium', 'Easy', 'Easy', 'Medium', 'Hard'],
  },
]

const PROJECT_DAYS = new Set([10, 15, 25, 30, 40, 50, 60])

function arcFor(day) {
  return ARCS.find((a) => day >= a.range[0] && day <= a.range[1])
}

function buildRequirements(title, skills) {
  return [
    `Implement the core functionality described in "${title}".`,
    `Use only the listed skills: ${skills.join(', ')}.`,
    'Make the layout fully responsive across mobile, tablet, and desktop.',
    'Push your code to a public GitHub repository with a clear commit history.',
  ]
}

export const CHALLENGES = Array.from({ length: 60 }, (_, i) => {
  const day = i + 1
  const arc = arcFor(day)
  const idxInArc = day - arc.range[0]
  const title = arc.titles[idxInArc] || `${arc.name} Challenge`
  const difficulty = arc.difficulty[idxInArc] || 'Medium'
  const estimatedTime = difficulty === 'Easy' ? '30–45 min' : difficulty === 'Medium' ? '60–90 min' : '90–120 min'

  return {
    id: `day-${day}`,
    day,
    title,
    description: `On Day ${day}, you'll practice ${arc.skills.join(' + ')} by shipping a real, working piece of UI: "${title}." This challenge builds directly on what you learned in the ${arc.name} arc and prepares you for what's next.`,
    difficulty,
    estimatedTime,
    skills: arc.skills,
    learningObjectives: [
      `Apply ${arc.skills[0]} concepts in a real, shippable build.`,
      'Practice breaking a feature into small, testable steps.',
      'Get comfortable committing and documenting your work like a pro.',
    ],
    requirements: buildRequirements(title, arc.skills),
    resources: [
      { label: 'MDN Web Docs', url: 'https://developer.mozilla.org' },
      { label: 'ABTalks Challenge Archive', url: '#' },
    ],
    arc: arc.name,
    isProject: PROJECT_DAYS.has(day),
  }
})

export function getChallengeByDay(day) {
  return CHALLENGES.find((c) => c.day === day)
}

export const TOTAL_DAYS = 60

// Realistic seed state for the hackathon demo: Day 18, an honest streak
// story (11-day opening run, an unresolved miss, then a fresh rebuild),
// and a handful of unlocked achievements.

export const STUDENT = {
  name: 'Sruthi Reddy',
  handle: '@sruthi.codes',
  currentDay: 18,
}

// status: 'completed' | 'recovery' | 'missed' | 'today' | 'upcoming'
// Demo story: an 11-day opening streak, a missed Day 12 that's still
// unresolved (so Recovery Mode is live the moment the app opens), then a
// fresh 5-day rebuild streak heading into today, Day 18.
function buildInitialDayStatus() {
  const status = {}
  for (let day = 1; day <= 60; day++) {
    if (day <= 11) status[day] = 'completed'
    else if (day === 12) status[day] = 'missed'
    else if (day < 18) status[day] = 'completed'
    else if (day === 18) status[day] = 'today'
    else status[day] = 'upcoming'
  }
  return status
}

export const INITIAL_STATE = {
  currentDay: 18,
  dayStatus: buildInitialDayStatus(),
  proofs: {
    // day: { github, linkedin, demo, submittedAt }
  },
}

export const ACHIEVEMENTS = [
  {
    id: 'streak-7',
    icon: 'Flame',
    label: '7-Day Streak',
    description: 'Keep your coding streak alive for 7 days straight.',
    check: (stats) => stats.currentStreak >= 7,
  },
  {
    id: 'completed-10',
    icon: 'Trophy',
    label: '10 Challenges Completed',
    description: 'Finish 10 daily challenges.',
    check: (stats) => stats.completedCount >= 10,
  },
  {
    id: 'first-project',
    icon: 'Laptop',
    label: 'First Project',
    description: 'Ship your first full project-day challenge.',
    check: (stats) => stats.projectsCompleted >= 1,
  },
  {
    id: 'warrior-30',
    icon: 'Rocket',
    label: '30-Day Warrior',
    description: 'Reach Day 30 of the challenge.',
    check: (stats) => stats.currentDay >= 30,
  },
  {
    id: 'halfway',
    icon: 'Target',
    label: 'Halfway There',
    description: 'Complete 30 challenges — you are halfway home.',
    check: (stats) => stats.completedCount >= 30,
  },
  {
    id: 'finisher-60',
    icon: 'Crown',
    label: '60-Day Finisher',
    description: 'Complete all 60 days of the challenge.',
    check: (stats) => stats.completedCount >= 60,
  },
]

export const MOTIVATIONAL_MESSAGES = {
  early: [
    'Every expert started with Day 1.',
    "Small steps, every day — that's the whole game.",
    'You showed up. That already puts you ahead of yesterday.',
  ],
  streak: [
    "You've built a habit. Keep going!",
    'Consistency is compounding — you can feel it now.',
    "This is what momentum looks like. Don't stop.",
  ],
  milestone: [
    "You're halfway there! 🚀",
    'Big milestone unlocked — look how far you have come.',
  ],
  missed: [
    "One missed day doesn't define your journey.",
    'A pause is not a stop. Recovery mode has you covered.',
  ],
  nearEnd: [
    'Only a few days left. Finish strong!',
    'The last stretch is where transformations happen.',
  ],
}

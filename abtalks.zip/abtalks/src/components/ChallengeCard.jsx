import React from 'react'
import { useNavigate } from 'react-router-dom'
import { Clock, Zap, ArrowRight, CheckCircle2, Circle, AlertCircle, RotateCcw } from 'lucide-react'

const DIFFICULTY_STYLES = {
  Easy: 'text-teal-400 bg-teal-400/10 border-teal-400/20',
  Medium: 'text-ember-400 bg-ember-400/10 border-ember-400/20',
  Hard: 'text-ember-600 bg-ember-600/10 border-ember-600/25',
}

const STATUS_META = {
  completed: { icon: CheckCircle2, text: 'Completed', color: 'text-teal-400' },
  recovery: { icon: RotateCcw, text: 'Recovered', color: 'text-teal-400' },
  missed: { icon: AlertCircle, text: 'Missed', color: 'text-ember-600' },
  today: { icon: Circle, text: 'In progress', color: 'text-ember-400' },
  upcoming: { icon: Circle, text: 'Upcoming', color: 'text-ink-400' },
}

export default function ChallengeCard({ challenge, status = 'today', variant = 'hero' }) {
  const navigate = useNavigate()
  const meta = STATUS_META[status] || STATUS_META.upcoming
  const StatusIcon = meta.icon

  if (variant === 'compact') {
    return (
      <button
        onClick={() => navigate(`/app/challenges/${challenge.day}`)}
        className="w-full flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] hover:bg-white/[0.05] hover:border-white/[0.1] transition-colors text-left group"
      >
        <div className="w-11 h-11 shrink-0 rounded-lg bg-white/[0.04] flex items-center justify-center font-mono text-xs font-semibold text-ink-300">
          {String(challenge.day).padStart(2, '0')}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm text-ink-100 truncate">{challenge.title}</p>
          <div className="flex items-center gap-3 mt-1 text-xs text-ink-400">
            <span className={`inline-flex items-center gap-1 ${meta.color}`}>
              <StatusIcon size={12} />
              {meta.text}
            </span>
            <span>{challenge.estimatedTime}</span>
          </div>
        </div>
        <span className={`hidden sm:inline-flex text-[11px] font-medium px-2 py-1 rounded-md border ${DIFFICULTY_STYLES[challenge.difficulty]}`}>
          {challenge.difficulty}
        </span>
        <ArrowRight size={16} className="text-ink-400 group-hover:text-ink-100 group-hover:translate-x-0.5 transition-all shrink-0" />
      </button>
    )
  }

  return (
    <div className="glass-card p-6 sm:p-8">
      <div className="flex items-center justify-between mb-4">
        <p className="eyebrow">Today's Mission</p>
        <span className={`text-[11px] font-medium px-2.5 py-1 rounded-md border ${DIFFICULTY_STYLES[challenge.difficulty]}`}>
          {challenge.difficulty}
        </span>
      </div>
      <h3 className="font-display text-xl sm:text-2xl font-semibold mb-2">
        Day {challenge.day} — {challenge.title}
      </h3>
      <p className="text-ink-400 text-sm leading-relaxed mb-5">{challenge.description}</p>
      <div className="flex flex-wrap items-center gap-4 mb-6 text-sm text-ink-300">
        <span className="inline-flex items-center gap-1.5">
          <Clock size={15} className="text-ink-400" /> {challenge.estimatedTime}
        </span>
        <span className="inline-flex items-center gap-1.5">
          <Zap size={15} className="text-ink-400" /> {challenge.skills.join(' · ')}
        </span>
      </div>
      <div className="flex flex-wrap gap-3">
        <button onClick={() => navigate(`/app/challenges/${challenge.day}`)} className="btn-primary">
          Start Challenge <ArrowRight size={16} />
        </button>
        <button onClick={() => navigate(`/app/challenges/${challenge.day}`)} className="btn-secondary">
          View Details
        </button>
      </div>
    </div>
  )
}

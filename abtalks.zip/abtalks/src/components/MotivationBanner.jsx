import React from 'react'
import { Sparkles } from 'lucide-react'

export default function MotivationBanner({ message }) {
  return (
    <div className="flex items-center gap-3 px-5 py-3.5 rounded-xl bg-white/[0.03] border border-white/[0.06]">
      <Sparkles size={16} className="text-ember-400 shrink-0" />
      <p className="text-sm text-ink-300 font-medium">{message}</p>
    </div>
  )
}

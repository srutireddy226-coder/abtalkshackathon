import React from 'react'
import { NavLink } from 'react-router-dom'
import { LayoutDashboard, CalendarDays, LineChart, Trophy, Flame, Settings as SettingsIcon } from 'lucide-react'

const NAV = [
  { to: '/app', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/app/challenges', label: 'Challenges', icon: CalendarDays },
  { to: '/app/progress', label: 'My Progress', icon: LineChart },
  { to: '/app/achievements', label: 'Achievements', icon: Trophy },
  { to: '/app/settings', label: 'Settings', icon: SettingsIcon },
]

export default function Sidebar() {
  return (
    <aside className="hidden lg:flex flex-col w-64 shrink-0 h-screen sticky top-0 border-r border-white/[0.06] px-5 py-6">
      <a href="#/" className="flex items-center gap-2.5 px-2 mb-8">
        <div className="w-8 h-8 rounded-lg bg-ember-gradient flex items-center justify-center shadow-ember">
          <Flame size={17} className="text-void-300" strokeWidth={2.5} />
        </div>
        <span className="font-display font-semibold text-[17px] tracking-tight">ABTalks</span>
      </a>
      <nav className="flex-1 space-y-1">
        {NAV.map(({ to, label, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors duration-150 ${
                isActive ? 'bg-white/[0.06] text-ink-100' : 'text-ink-400 hover:text-ink-100 hover:bg-white/[0.03]'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <Icon size={18} strokeWidth={2} className={isActive ? 'text-ember-400' : ''} />
                {label}
              </>
            )}
          </NavLink>
        ))}
      </nav>
      <div className="glass-card p-4">
        <p className="eyebrow mb-1.5">60-Day Challenge</p>
        <p className="text-xs text-ink-400 leading-relaxed">
          One rep at a time. Every day you show up compounds into the developer you're becoming.
        </p>
      </div>
    </aside>
  )
}

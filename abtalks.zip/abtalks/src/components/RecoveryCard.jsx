import React from 'react'
import { useNavigate } from 'react-router-dom'
import { LifeBuoy, CheckCircle2, ArrowRight, PartyPopper } from 'lucide-react'

export default function RecoveryCard({ plan }) {
  const navigate = useNavigate()

  if (!plan) {
    return (
      <div className="glass-card p-6 border-teal-400/20 relative overflow-hidden">
        <div className="absolute -right-6 -top-6 w-28 h-28 rounded-full bg-teal-400/10 blur-2xl" />
        <div className="flex items-start gap-3 relative">
          <div className="w-10 h-10 rounded-xl bg-teal-gradient flex items-center justify-center shrink-0">
            <PartyPopper size={18} className="text-void-300" />
          </div>
          <div>
            <p className="font-display font-semibold text-ink-100 mb-1">You're on track!</p>
            <p className="text-sm text-ink-400">Keep the streak alive 🔥 — no missed days on record.</p>
          </div>
        </div>
      </div>
    )
  }

  const { missedDay, missedChallenge, todayChallenge } = plan

  return (
    <div className="glass-card p-6 border-ember-500/25 relative overflow-hidden">
      <div className="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-ember-500/10 blur-2xl" />
      <div className="flex items-start gap-3 mb-5 relative">
        <div className="w-10 h-10 rounded-xl bg-ember-gradient flex items-center justify-center shrink-0 shadow-ember">
          <LifeBuoy size={18} className="text-void-300" />
        </div>
        <div>
          <p className="eyebrow mb-1 text-ember-400">Recovery Mode</p>
          <p className="font-display font-semibold text-ink-100">Looks like you missed Day {missedDay}.</p>
          <p className="text-sm text-ink-400 mt-0.5">Let's get you back on track. 💪</p>
        </div>
      </div>

      <div className="space-y-2.5 mb-5">
        <RecoveryStep dayNumber={missedChallenge.day} label="Quick Recovery Task" time="30 minutes" onClick={() => navigate(`/app/challenges/${missedChallenge.day}`)} />
        <RecoveryStep dayNumber={todayChallenge.day} label="Today's Challenge" time="90 minutes" onClick={() => navigate(`/app/challenges/${todayChallenge.day}`)} />
      </div>

      <p className="text-xs text-ink-400 mb-4">Complete today's recovery task to continue your journey.</p>

      <button onClick={() => navigate(`/app/challenges/${missedChallenge.day}`)} className="btn-primary w-full">
        Start Recovery <ArrowRight size={16} />
      </button>
    </div>
  )
}

function RecoveryStep({ dayNumber, label, time, onClick }) {
  return (
    <button onClick={onClick} className="w-full flex items-center gap-3 p-3 rounded-xl bg-white/[0.03] border border-white/[0.06] hover:bg-white/[0.06] transition-colors text-left">
      <div className="w-9 h-9 rounded-lg bg-white/[0.05] flex items-center justify-center font-mono text-xs font-semibold shrink-0">{dayNumber}</div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-ink-100">{label}</p>
        <p className="text-xs text-ink-400">{time}</p>
      </div>
      <CheckCircle2 size={16} className="text-ink-400 shrink-0" />
    </button>
  )
}

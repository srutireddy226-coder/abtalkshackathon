import React from 'react'
import { Flame } from 'lucide-react'

const DAY_LABELS = ['M', 'T', 'W', 'T', 'F', 'S', 'S']

export default function StreakCard({ stats, dayStatus }) {
  const currentDay = stats.currentDay
  const startDay = Math.max(1, currentDay - 6)
  const last7 = []
  for (let d = startDay; d <= currentDay; d++) {
    last7.push({ day: d, status: dayStatus[d] })
  }
  while (last7.length < 7) last7.unshift({ day: null, status: null })

  return (
    <div className="glass-card p-6">
      <div className="flex items-center justify-between mb-5">
        <p className="eyebrow">Current Streak</p>
        <Flame size={16} className="text-ember-400" />
      </div>
      <div className="flex items-end gap-2 mb-6">
        <span className="font-display text-4xl font-bold text-ember-400 animate-flicker">{stats.currentStreak}</span>
        <span className="text-ink-400 text-sm mb-1.5">day streak</span>
      </div>
      <div className="grid grid-cols-7 gap-2">
        {last7.map((d, i) => {
          const active = d.status === 'completed' || d.status === 'recovery'
          const isToday = d.status === 'today'
          const missed = d.status === 'missed'
          return (
            <div key={i} className="flex flex-col items-center gap-1.5">
              <div
                className={`w-full aspect-square rounded-lg flex items-center justify-center transition-colors ${
                  active
                    ? 'bg-ember-gradient shadow-ember'
                    : isToday
                    ? 'bg-white/[0.06] border-2 border-ember-500/60'
                    : missed
                    ? 'bg-ember-700/20 border border-ember-700/40'
                    : 'bg-white/[0.03] border border-white/[0.06]'
                }`}
              >
                {active && <Flame size={13} className="text-void-300" />}
              </div>
              <span className="text-[10px] text-ink-400 font-mono">{d.day ? DAY_LABELS[(d.day - 1) % 7] : ''}</span>
            </div>
          )
        })}
      </div>
      <p className="text-xs text-ink-400 mt-5 pt-4 border-t border-white/[0.06]">
        Longest streak: <span className="text-ink-100 font-medium">{stats.longestStreak} days</span>
      </p>
    </div>
  )
}

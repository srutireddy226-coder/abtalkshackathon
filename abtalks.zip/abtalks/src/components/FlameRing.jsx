import React from 'react'
import { Flame } from 'lucide-react'

export default function FlameRing({ percent = 0, size = 200, label, sublabel }) {
  const stroke = size * 0.07
  const radius = (size - stroke) / 2
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (percent / 100) * circumference

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id="flameGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFB088" />
            <stop offset="45%" stopColor="#FF7A3D" />
            <stop offset="100%" stopColor="#E85D2C" />
          </linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="url(#flameGradient)"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{
            transition: 'stroke-dashoffset 1.1s cubic-bezier(0.16,1,0.3,1)',
            filter: 'drop-shadow(0 0 10px rgba(255,122,61,0.55))',
          }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <Flame size={size * 0.16} className="text-ember-400 animate-flicker mb-1" fill="#FF7A3D" strokeWidth={1.5} />
        <span className="font-display font-bold" style={{ fontSize: size * 0.15 }}>
          {label}
        </span>
        {sublabel && <span className="text-ink-400 text-xs mt-0.5">{sublabel}</span>}
      </div>
    </div>
  )
}

import React from 'react'
import { Trophy, Flame, Laptop, Rocket, Target, Crown } from 'lucide-react'

const ICONS = { Flame, Trophy, Laptop, Rocket, Target, Crown }

export default function CelebrationToast({ achievement }) {
  const Icon = ICONS[achievement.icon] || Trophy
  return (
    <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 animate-pop">
      <div className="glass-card px-5 py-4 flex items-center gap-3 shadow-glow border-ember-500/40">
        <div className="w-10 h-10 rounded-xl bg-ember-gradient flex items-center justify-center shrink-0">
          <Icon size={19} className="text-void-300" />
        </div>
        <div>
          <p className="text-xs text-ember-400 font-mono uppercase tracking-wide">Achievement Unlocked</p>
          <p className="font-display font-semibold text-sm">{achievement.label}</p>
        </div>
      </div>
    </div>
  )
}

import React, { useState } from 'react'
import { Bell, Sun, Moon, Flame } from 'lucide-react'
import { useStudent } from '../context/StudentContext'

export default function Navbar() {
  const { student, stats } = useStudent()
  const [theme, setTheme] = useState('dark')
  const [notifOpen, setNotifOpen] = useState(false)

  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark'
    setTheme(next)
    document.documentElement.classList.toggle('light', next === 'light')
  }

  const initials = student.name.split(' ').map((n) => n[0]).join('').slice(0, 2)

  return (
    <header className="sticky top-0 z-30 bg-void/80 backdrop-blur-xl border-b border-white/[0.06]">
      <div className="flex items-center justify-between px-4 sm:px-6 lg:px-10 h-16">
        <div className="lg:hidden flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-ember-gradient flex items-center justify-center">
            <Flame size={14} className="text-void-300" strokeWidth={2.5} />
          </div>
          <span className="font-display font-semibold text-[15px]">ABTalks</span>
        </div>

        <div className="hidden lg:flex items-center gap-2 text-sm text-ink-400">
          <span className="font-mono text-ember-400 font-medium">Day {stats.currentDay}</span>
          <span>/ 60 · {stats.completionPct}% complete</span>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <button onClick={toggleTheme} aria-label="Toggle theme" className="w-9 h-9 rounded-lg flex items-center justify-center text-ink-400 hover:text-ink-100 hover:bg-white/[0.05] transition-colors">
            {theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}
          </button>

          <div className="relative">
            <button onClick={() => setNotifOpen((v) => !v)} aria-label="Notifications" className="w-9 h-9 rounded-lg flex items-center justify-center text-ink-400 hover:text-ink-100 hover:bg-white/[0.05] transition-colors relative">
              <Bell size={17} />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-ember-500" />
            </button>
            {notifOpen && (
              <div className="absolute right-0 mt-2 w-72 glass-card p-3 animate-rise z-40">
                <p className="eyebrow mb-2 px-1">Notifications</p>
                <div className="space-y-1">
                  <div className="px-3 py-2 rounded-lg hover:bg-white/[0.04] text-sm">
                    <p className="text-ink-100 font-medium">Day {stats.currentDay} is live</p>
                    <p className="text-ink-400 text-xs mt-0.5">Your next challenge is ready when you are.</p>
                  </div>
                  <div className="px-3 py-2 rounded-lg hover:bg-white/[0.04] text-sm">
                    <p className="text-ink-100 font-medium">Recovery Mode available</p>
                    <p className="text-ink-400 text-xs mt-0.5">Catch up on a missed day without breaking stride.</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2.5 pl-2 sm:pl-3 border-l border-white/[0.06]">
            <div className="w-9 h-9 rounded-full bg-teal-gradient flex items-center justify-center text-void-300 font-display font-semibold text-xs">
              {initials}
            </div>
            <div className="hidden sm:block leading-tight">
              <p className="text-sm font-medium text-ink-100">{student.name}</p>
              <p className="text-xs text-ink-400">{student.handle}</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}

import React, { useState } from 'react'
import { Github, Linkedin, Link2, UploadCloud, CheckCircle2 } from 'lucide-react'

export default function ProofSubmission({ day, existingProof, onSubmit }) {
  const [github, setGithub] = useState(existingProof?.github || '')
  const [linkedin, setLinkedin] = useState(existingProof?.linkedin || '')
  const [demo, setDemo] = useState(existingProof?.demo || '')
  const [fileName, setFileName] = useState(existingProof?.fileName || '')
  const [justSubmitted, setJustSubmitted] = useState(false)

  const handleFile = (e) => {
    const file = e.target.files?.[0]
    if (file) setFileName(file.name)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!github.trim()) return
    onSubmit({ github, linkedin, demo, fileName })
    setJustSubmitted(true)
    window.setTimeout(() => setJustSubmitted(false), 3000)
  }

  return (
    <form onSubmit={handleSubmit} className="glass-card p-6">
      <p className="eyebrow mb-1">Proof of Work</p>
      <h3 className="font-display font-semibold text-lg mb-5">Submit Day {day}</h3>

      <div className="space-y-4">
        <Field icon={Github} label="GitHub repository URL" required>
          <input type="url" required value={github} onChange={(e) => setGithub(e.target.value)} placeholder="https://github.com/you/day-18-portfolio" className="input" />
        </Field>
        <Field icon={Linkedin} label="LinkedIn post URL (optional)">
          <input type="url" value={linkedin} onChange={(e) => setLinkedin(e.target.value)} placeholder="https://linkedin.com/posts/..." className="input" />
        </Field>
        <Field icon={Link2} label="Live project / demo URL (optional)">
          <input type="url" value={demo} onChange={(e) => setDemo(e.target.value)} placeholder="https://your-demo.vercel.app" className="input" />
        </Field>
        <div>
          <label className="text-xs font-medium text-ink-400 mb-1.5 block">Screenshot proof (optional)</label>
          <label className="flex flex-col items-center justify-center gap-2 border-2 border-dashed border-white/10 rounded-xl py-8 cursor-pointer hover:border-ember-500/40 hover:bg-white/[0.02] transition-colors">
            <UploadCloud size={22} className="text-ink-400" />
            <span className="text-xs text-ink-400">{fileName ? <span className="text-ink-100">{fileName}</span> : 'Click to upload a screenshot'}</span>
            <input type="file" accept="image/*" className="hidden" onChange={handleFile} />
          </label>
        </div>
      </div>

      <button type="submit" className="btn-primary w-full mt-6">
        {existingProof ? 'Update Submission' : 'Submit Proof'}
      </button>

      {(justSubmitted || existingProof) && (
        <p className="flex items-center gap-1.5 text-teal-400 text-sm mt-3 justify-center animate-rise">
          <CheckCircle2 size={15} /> Proof submitted successfully ✓
        </p>
      )}

      <style>{`
        .input { width: 100%; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 0.75rem; padding: 0.6rem 0.85rem; font-size: 0.875rem; color: #F4F6FB; }
        .input:focus { border-color: rgba(255,146,87,0.5); outline: none; }
        .input::placeholder { color: #5B6479; }
      `}</style>
    </form>
  )
}

function Field({ icon: Icon, label, required, children }) {
  return (
    <div>
      <label className="flex items-center gap-1.5 text-xs font-medium text-ink-400 mb-1.5">
        <Icon size={13} /> {label} {required && <span className="text-ember-500">*</span>}
      </label>
      {children}
    </div>
  )
}

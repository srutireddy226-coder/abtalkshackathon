import React from 'react'
import { NavLink } from 'react-router-dom'
import { LayoutDashboard, CalendarDays, LineChart, Trophy, Settings as SettingsIcon } from 'lucide-react'

const NAV = [
  { to: '/app', label: 'Home', icon: LayoutDashboard, end: true },
  { to: '/app/challenges', label: 'Challenges', icon: CalendarDays },
  { to: '/app/progress', label: 'Progress', icon: LineChart },
  { to: '/app/achievements', label: 'Badges', icon: Trophy },
  { to: '/app/settings', label: 'Settings', icon: SettingsIcon },
]

export default function BottomNav() {
  return (
    <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-void-100/95 backdrop-blur-xl border-t border-white/[0.06] px-2 py-2 flex items-center justify-around">
      {NAV.map(({ to, label, icon: Icon, end }) => (
        <NavLink
          key={to}
          to={to}
          end={end}
          className={({ isActive }) => `flex flex-col items-center gap-1 px-3 py-1.5 rounded-lg text-[10px] font-medium ${isActive ? 'text-ember-400' : 'text-ink-400'}`}
        >
          <Icon size={20} strokeWidth={2} />
          {label}
        </NavLink>
      ))}
    </nav>
  )
}

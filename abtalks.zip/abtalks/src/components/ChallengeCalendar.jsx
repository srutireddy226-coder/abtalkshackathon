import React from 'react'
import { useNavigate } from 'react-router-dom'
import { Check, Flame, RotateCcw, X } from 'lucide-react'
import { CHALLENGES } from '../data/challenges'
import { calendarStatusFor } from '../utils/progress'

const STATUS_STYLE = {
  completed: 'bg-ember-gradient text-void-300 shadow-ember',
  today: 'bg-white/[0.06] border-2 border-ember-500 text-ink-100',
  recovery: 'bg-teal-gradient text-void-300',
  missed: 'bg-ember-700/25 border border-ember-700/50 text-ember-300',
  upcoming: 'bg-white/[0.03] border border-white/[0.06] text-ink-400',
}

function StatusGlyph({ status }) {
  if (status === 'completed') return <Check size={13} strokeWidth={3} />
  if (status === 'today') return <Flame size={13} className="text-ember-400" />
  if (status === 'recovery') return <RotateCcw size={12} strokeWidth={2.5} />
  if (status === 'missed') return <X size={12} strokeWidth={2.5} />
  return null
}

export default function ChallengeCalendar({ dayStatus, currentDay, compact = false }) {
  const navigate = useNavigate()

  return (
    <div className="glass-card p-6">
      <div className="flex items-center justify-between mb-5">
        <div>
          <p className="eyebrow mb-1">Challenge Calendar</p>
          <p className="text-sm text-ink-400">60 days, one square at a time.</p>
        </div>
        {!compact && (
          <div className="hidden sm:flex items-center gap-3 text-[11px] text-ink-400">
            <Legend color="bg-ember-gradient" label="Done" />
            <Legend color="bg-white/[0.06] border-2 border-ember-500" label="Today" />
            <Legend color="bg-teal-gradient" label="Recovery" />
            <Legend color="bg-ember-700/25 border border-ember-700/50" label="Missed" />
            <Legend color="bg-white/[0.03] border border-white/[0.06]" label="Upcoming" />
          </div>
        )}
      </div>
      <div className="grid grid-cols-6 sm:grid-cols-10 gap-2">
        {CHALLENGES.map((c) => {
          const status = calendarStatusFor(dayStatus, c.day, currentDay)
          return (
            <button
              key={c.day}
              onClick={() => navigate(`/app/challenges/${c.day}`)}
              title={`Day ${c.day}: ${c.title}`}
              className={`aspect-square rounded-lg flex flex-col items-center justify-center gap-0.5 text-[11px] font-mono font-medium transition-transform hover:scale-105 ${STATUS_STYLE[status]}`}
            >
              <StatusGlyph status={status} />
              <span>{c.day}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}

function Legend({ color, label }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={`w-2.5 h-2.5 rounded-[3px] ${color}`} />
      {label}
    </span>
  )
}

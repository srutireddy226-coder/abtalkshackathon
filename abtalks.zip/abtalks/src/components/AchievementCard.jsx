import React from 'react'
import { Flame, Trophy, Laptop, Rocket, Target, Crown, Lock } from 'lucide-react'

const ICONS = { Flame, Trophy, Laptop, Rocket, Target, Crown }

export default function AchievementCard({ achievement }) {
  const Icon = ICONS[achievement.icon] || Trophy
  const { unlocked } = achievement

  return (
    <div className={`glass-card p-5 flex flex-col items-center text-center transition-all duration-300 ${unlocked ? 'animate-pop' : 'opacity-60 grayscale'}`}>
      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-3 ${unlocked ? 'bg-ember-gradient shadow-ember' : 'bg-white/[0.05] border border-white/[0.08]'}`}>
        {unlocked ? <Icon size={24} className="text-void-300" strokeWidth={2} /> : <Lock size={20} className="text-ink-400" />}
      </div>
      <p className="font-display font-semibold text-sm text-ink-100 mb-1">{achievement.label}</p>
      <p className="text-xs text-ink-400 leading-relaxed">{achievement.description}</p>
      {unlocked && (
        <span className="mt-3 text-[10px] font-mono uppercase tracking-wider text-teal-400 bg-teal-400/10 border border-teal-400/20 px-2 py-0.5 rounded-full">
          Unlocked
        </span>
      )}
    </div>
  )
}

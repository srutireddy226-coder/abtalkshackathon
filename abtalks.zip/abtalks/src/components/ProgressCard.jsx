import React from 'react'
import { Flame, CheckCircle2, Layers } from 'lucide-react'
import FlameRing from './FlameRing'

export default function ProgressCard({ stats }) {
  return (
    <div className="glass-card p-6 sm:p-8 bg-aurora">
      <div className="flex flex-col sm:flex-row items-center sm:items-start gap-8">
        <FlameRing percent={stats.completionPct} size={176} label={`${stats.completionPct}%`} sublabel={`Day ${stats.currentDay} / 60`} />
        <div className="flex-1 w-full">
          <p className="eyebrow mb-1">Challenge Progress</p>
          <h2 className="font-display text-2xl font-semibold mb-1">Day {stats.currentDay} of 60</h2>
          <p className="text-ink-400 text-sm mb-6">{stats.completionPct}% completed — you're building real momentum.</p>
          <div className="grid grid-cols-3 gap-3">
            <Stat icon={Flame} value={stats.currentStreak} label="Day streak" accent="ember" />
            <Stat icon={CheckCircle2} value={stats.completedCount} label="Completed" accent="teal" />
            <Stat icon={Layers} value={stats.projectsCompleted} label="Projects" accent="ember" />
          </div>
        </div>
      </div>
    </div>
  )
}

function Stat({ icon: Icon, value, label, accent }) {
  const color = accent === 'ember' ? 'text-ember-400' : 'text-teal-400'
  return (
    <div className="rounded-xl bg-white/[0.03] border border-white/[0.06] px-4 py-3.5">
      <Icon size={16} className={`${color} mb-2`} />
      <p className="font-display text-xl font-bold leading-none">{value}</p>
      <p className="text-ink-400 text-xs mt-1.5">{label}</p>
    </div>
  )
}

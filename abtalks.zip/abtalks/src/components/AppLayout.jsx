import React from 'react'
import { Outlet } from 'react-router-dom'
import Sidebar from './Sidebar'
import BottomNav from './BottomNav'
import Navbar from './Navbar'
import CelebrationToast from './CelebrationToast'
import { useStudent } from '../context/StudentContext'

export default function AppLayout() {
  const { celebration, achievements } = useStudent()
  const unlockedMeta = achievements.find((a) => a.id === celebration)

  return (
    <div className="min-h-screen bg-void text-ink-100">
      <div className="flex">
        <Sidebar />
        <div className="flex-1 min-w-0">
          <Navbar />
          <main className="px-4 sm:px-6 lg:px-10 py-6 pb-24 lg:pb-10 max-w-[1400px] mx-auto">
            <Outlet />
          </main>
        </div>
      </div>
      <BottomNav />
      {unlockedMeta && <CelebrationToast achievement={unlockedMeta} />}
    </div>
  )
}

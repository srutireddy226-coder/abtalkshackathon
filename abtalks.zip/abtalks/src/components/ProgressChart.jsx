import React from 'react'
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'

const TOOLTIP_STYLE = {
  background: '#131826',
  border: '1px solid rgba(255,255,255,0.08)',
  borderRadius: 10,
  fontSize: 12,
  color: '#F4F6FB',
}

export function WeeklyProgressChart({ dayStatus, currentDay }) {
  const startDay = Math.max(1, currentDay - 6)
  const data = []
  for (let d = startDay; d <= startDay + 6; d++) {
    const s = dayStatus[d]
    const done = s === 'completed' || s === 'recovery'
    data.push({
      name: `Day ${d}`,
      value: done ? 1 : s === 'missed' ? 0.15 : s === 'today' ? 0.5 : 0,
    })
  }

  return (
    <div className="glass-card p-6">
      <p className="eyebrow mb-1">Weekly Progress</p>
      <p className="text-sm text-ink-400 mb-4">Challenge completion this week</p>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={data} barCategoryGap="30%">
          <CartesianGrid vertical={false} stroke="rgba(255,255,255,0.05)" />
          <XAxis dataKey="name" tick={{ fill: '#8A93A6', fontSize: 11 }} tickFormatter={(v) => v.replace('Day ', 'D')} axisLine={false} tickLine={false} />
          <YAxis hide domain={[0, 1]} />
          <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v) => [v >= 1 ? 'Completed' : v >= 0.5 ? 'In progress' : v > 0 ? 'Missed' : 'Upcoming', '']} />
          <Bar dataKey="value" radius={[6, 6, 6, 6]} fill="#FF7A3D" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

export function JourneyChart({ stats }) {
  const milestones = [1, 15, 30, 45, 60]
  const data = milestones.map((day) => ({
    day: `Day ${day}`,
    progress: Math.min(100, Math.round((Math.min(day, stats.currentDay) / 60) * 100)),
  }))

  return (
    <div className="glass-card p-6">
      <p className="eyebrow mb-1">Your Journey</p>
      <p className="text-sm text-ink-400 mb-4">Day 1 → Day 60</p>
      <ResponsiveContainer width="100%" height={220}>
        <LineChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
          <CartesianGrid vertical={false} stroke="rgba(255,255,255,0.05)" />
          <XAxis dataKey="day" tick={{ fill: '#8A93A6', fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fill: '#8A93A6', fontSize: 11 }} axisLine={false} tickLine={false} unit="%" />
          <Tooltip contentStyle={TOOLTIP_STYLE} formatter={(v) => [`${v}%`, 'Progress']} />
          <Line type="monotone" dataKey="progress" stroke="#37E6C4" strokeWidth={2.5} dot={{ fill: '#37E6C4', r: 4 }} activeDot={{ r: 6 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

import { useMemo, useState, useCallback, useEffect, useRef } from 'react'
import { useLocalStorage } from './useLocalStorage'
import { INITIAL_STATE, STUDENT } from '../data/studentState'
import { TOTAL_DAYS } from '../data/challenges'
import {
  computeStats,
  getUnlockedAchievements,
  getRecoveryPlan,
  pickMotivationalMessage,
} from '../utils/progress'

export function useStudentProgress() {
  const [state, setState] = useLocalStorage('abtalks:state:v1', INITIAL_STATE)
  const [celebration, setCelebration] = useState(null)

  const stats = useMemo(() => computeStats(state.dayStatus, state.currentDay), [state])
  const achievements = useMemo(() => getUnlockedAchievements(stats), [stats])
  const recoveryPlan = useMemo(() => getRecoveryPlan(state.dayStatus, state.currentDay), [state])
  const motivation = useMemo(() => pickMotivationalMessage(stats), [stats])

  const unlockedIds = useMemo(
    () => new Set(achievements.filter((a) => a.unlocked).map((a) => a.id)),
    [achievements]
  )

  const prevUnlockedRef = useRef(null)
  useEffect(() => {
    if (prevUnlockedRef.current) {
      for (const id of unlockedIds) {
        if (!prevUnlockedRef.current.has(id)) {
          setCelebration(id)
          window.setTimeout(() => setCelebration(null), 2400)
          break
        }
      }
    }
    prevUnlockedRef.current = unlockedIds
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [unlockedIds])

  const markComplete = useCallback(
    (day) => {
      setState((prev) => {
        const wasMissed = prev.dayStatus[day] === 'missed'
        const nextDayStatus = {
          ...prev.dayStatus,
          [day]: wasMissed ? 'recovery' : 'completed',
        }
        let nextCurrentDay = prev.currentDay
        if (day === prev.currentDay && day < TOTAL_DAYS) {
          nextCurrentDay = day + 1
          nextDayStatus[nextCurrentDay] = 'today'
        }
        return { ...prev, dayStatus: nextDayStatus, currentDay: nextCurrentDay }
      })
    },
    [setState]
  )

  const startRecovery = useCallback(
    (day) => {
      setState((prev) => ({
        ...prev,
        dayStatus: { ...prev.dayStatus, [day]: 'recovery' },
      }))
    },
    [setState]
  )

  const submitProof = useCallback(
    (day, proof) => {
      setState((prev) => {
        const wasMissed = prev.dayStatus[day] === 'missed'
        const nextDayStatus = { ...prev.dayStatus }
        if (nextDayStatus[day] !== 'completed' && nextDayStatus[day] !== 'recovery') {
          nextDayStatus[day] = wasMissed ? 'recovery' : 'completed'
        }
        let nextCurrentDay = prev.currentDay
        if (day === prev.currentDay && day < TOTAL_DAYS) {
          nextCurrentDay = day + 1
          nextDayStatus[nextCurrentDay] = 'today'
        }
        return {
          ...prev,
          dayStatus: nextDayStatus,
          currentDay: nextCurrentDay,
          proofs: {
            ...prev.proofs,
            [day]: { ...proof, submittedAt: new Date().toISOString() },
          },
        }
      })
    },
    [setState]
  )

  const resetDemo = useCallback(() => {
    setState(INITIAL_STATE)
  }, [setState])

  const triggerCelebration = useCallback((id) => {
    setCelebration(id)
    window.setTimeout(() => setCelebration(null), 2200)
  }, [])

  return {
    student: STUDENT,
    state,
    stats,
    achievements,
    unlockedIds,
    recoveryPlan,
    motivation,
    celebration,
    triggerCelebration,
    markComplete,
    startRecovery,
    submitProof,
    resetDemo,
  }
}

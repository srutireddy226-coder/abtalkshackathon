import { CHALLENGES, TOTAL_DAYS } from '../data/challenges'
import { ACHIEVEMENTS, MOTIVATIONAL_MESSAGES } from '../data/studentState'

const DONE_STATUSES = new Set(['completed', 'recovery'])

export function computeStats(dayStatus, currentDay) {
  let completedCount = 0
  let missedCount = 0
  let projectsCompleted = 0

  for (const c of CHALLENGES) {
    const s = dayStatus[c.day]
    if (DONE_STATUSES.has(s)) {
      completedCount += 1
      if (c.isProject) projectsCompleted += 1
    }
    if (s === 'missed') missedCount += 1
  }

  // Current streak: walk backward from the day before "today", counting an
  // unbroken run of completed/recovered days.
  let currentStreak = 0
  for (let d = currentDay - 1; d >= 1; d--) {
    if (DONE_STATUSES.has(dayStatus[d])) currentStreak += 1
    else break
  }
  if (DONE_STATUSES.has(dayStatus[currentDay])) currentStreak += 1

  // Longest streak: scan the whole timeline for the best run.
  let longestStreak = 0
  let run = 0
  for (let d = 1; d <= TOTAL_DAYS; d++) {
    if (DONE_STATUSES.has(dayStatus[d])) {
      run += 1
      longestStreak = Math.max(longestStreak, run)
    } else {
      run = 0
    }
  }

  const completionPct = Math.round((completedCount / TOTAL_DAYS) * 100)

  return {
    currentDay,
    completedCount,
    missedCount,
    projectsCompleted,
    currentStreak,
    longestStreak,
    completionPct,
  }
}

export function getUnlockedAchievements(stats) {
  return ACHIEVEMENTS.map((a) => ({ ...a, unlocked: a.check(stats) }))
}

export function getNextAchievement(stats) {
  const unlocked = getUnlockedAchievements(stats)
  return unlocked.find((a) => !a.unlocked) || null
}

// Returns the first unresolved missed day strictly before currentDay, or null.
export function getActiveMissedDay(dayStatus, currentDay) {
  for (let d = 1; d < currentDay; d++) {
    if (dayStatus[d] === 'missed') return d
  }
  return null
}

export function getRecoveryPlan(dayStatus, currentDay) {
  const missedDay = getActiveMissedDay(dayStatus, currentDay)
  if (missedDay == null) return null
  const missedChallenge = CHALLENGES.find((c) => c.day === missedDay)
  const todayChallenge = CHALLENGES.find((c) => c.day === currentDay)
  return {
    missedDay,
    missedChallenge,
    todayChallenge,
  }
}

export function pickMotivationalMessage(stats) {
  const { currentDay, currentStreak, missedCount, completedCount } = stats
  const pool = []
  if (completedCount === 30) return MOTIVATIONAL_MESSAGES.milestone[0]
  if (currentDay >= 55) pool.push(...MOTIVATIONAL_MESSAGES.nearEnd)
  if (missedCount > 0 && currentStreak < 3) pool.push(...MOTIVATIONAL_MESSAGES.missed)
  if (currentStreak >= 5) pool.push(...MOTIVATIONAL_MESSAGES.streak)
  if (currentDay <= 5) pool.push(...MOTIVATIONAL_MESSAGES.early)
  if (pool.length === 0) pool.push(...MOTIVATIONAL_MESSAGES.streak)

  const idx = currentDay % pool.length
  return pool[idx]
}

export function calendarStatusFor(dayStatus, day, currentDay) {
  if (day === currentDay) return 'today'
  const s = dayStatus[day]
  if (s === 'completed') return 'completed'
  if (s === 'recovery') return 'recovery'
  if (s === 'missed') return 'missed'
  return 'upcoming'
}
